/*:
## Exercise - Create Functions

 Write a function called `introduceMyself` that prints a brief introduction of yourself. Call the function and observe the printout.
 */
func introduceMyself(name : String, age : Int, nationality : String , born : String, Car : String, Model : Int, Color : String, Fathername : String , Fage : Int, Fwork : String) {
   
    print("My name is \(name) and iam \(age) years old im from \(nationality) i was born in \(born) my car is \(Car) that have great \(Color) and my car model is \(Model) i have great father his name \(Fathername) and my dad \(Fage) yers old my father work in \(Fwork) ")
}
 introduceMyself(name: "Abdulrazaq", age: 22, nationality: "Saudi Arabia", born: "Farasan island", Car: "Camry", Model: 2019, Color: "White", Fathername: "Ibrahim", Fage: 50, Fwork: "Deputy Director of Forsan General Hospital")
//:  Write a function called `magicEightBall` that generates a random number and then uses either a switch statement or if-else-if statements to print different responses based on the random number generated. `let randomNum = Int.random(in: 0...4)` will generate a random number from 0 to 4, after which you can print different phrases corresponding to the number generated. Call the function multiple times and observe the different printouts.
import Foundation
func magicEightBall() {
    let randomNum = Int.random(in: 0...4)
    switch randomNum {
    case 0:
        print("where your Love")
    case 1 :
        print("Do you find your Love")
    case 2 :
        print("good you have love with someone")
    case 3 :
        print("you very very happy with your wife")
    case 4 :
        print("you smile every time")
    
    default:
        print("error")
    }
}

magicEightBall()
/*:
page 1 of 6  |  [Next: App Exercise - A Functioning App](@next)
 */
